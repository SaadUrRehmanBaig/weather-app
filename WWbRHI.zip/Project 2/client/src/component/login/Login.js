import './login.css';
import React,{useState} from 'react';
import io from 'socket.io-client';

//io connection
const socket = io.connect("http://localhost:3001")


const Login = () => {

    //user input
    const [user,setUser] = useState({
        email:"",
        password:"",
    });
    
    //handling user input
    const handleChange = (e) =>{
        setUser({...user,[e.target.name]:e.target.value});
    }
    
    //login 
    const login = () =>{
        const {email,password} = user;
        if(email && password){
            socket.emit("login",{userData:user})           
        }
        else{
            alert("invalid input")
        }
    }

    return ( 
        <div className='main'>
            <div className="login">
                <h1> Login </h1>  
                <input type="email" required name= "email" onChange={handleChange}placeholder="Email"/>
                <input type="password" required name= "password" onChange={handleChange}placeholder="Enter Your Password"/>
                <div className="button" onClick={login}>Login</div>
                <div>or</div>
                <div className="button">Register</div>
            </div>
        </div>
    )

}

export default Login;