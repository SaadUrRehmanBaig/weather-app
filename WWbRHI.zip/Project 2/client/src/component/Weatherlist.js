// import React from 'react';
// import { Button } from '@material-ui/core';
// import { makeStyles } from '@material-ui/core/styles';
// import Paper from '@material-ui/core/Paper';
// import Grid from '@material-ui/core/Grid';

// const useStyles = makeStyles((theme) => ({
//   root: {
//     flexGrow: 1,
//   },
//   paper: {
//     padding: theme.spacing(2),
//     color:'secondary',
//     display:'flex',
//     justifyContent:'space-evenly',
//     border:'1px solid black',
  
// },
// }));

// export default function WeatherList() {
//   const classes = useStyles();

//   return (
//     <div className={classes.root}>
//       <Grid container spacing={3}>
//         <Grid item xs={12} >
//             <Button className={classes.button} variant="outlined" color="secondary">
//                 Secondary
//             </Button>
//         </Grid>        
//         <Grid item xs={6} >
//           <Paper className={classes.paper}>Karachi
//           <span>20</span>
//           </Paper>
          
//         </Grid>        
//         <Grid item xs={6} >
//           <Paper className={classes.paper}>Lahore
//           <span>20</span>
//           </Paper>
//         </Grid>        
//         <Grid item xs={6} >
//           <Paper className={classes.paper}>Islamabad
//           <span>20</span>
//           </Paper>
//         </Grid>        
//         <Grid item xs={6} >
//           <Paper className={classes.paper}>Quetta
//           <span>20</span>
//           </Paper>
//         </Grid>        
//         <Grid item xs={6} >
//           <Paper className={classes.paper}>Peshawar
//           <span>20</span>
//           </Paper>
//         </Grid>        
//       </Grid>
//     </div>
//   );
// }
