import React,{useEffect,useState} from 'react'
import io from 'socket.io-client'

const socket = io.connect("http://localhost:3001")

export default function DetailedWeather() {
  const [weather,setWeather] = useState([]);

  const sendmessage = () => {
    socket.emit("send_message",{message:"hello"})
  }

  useEffect(() => {
    socket.on("receive_message",(data)=>{
      // setWeather(data.main)
    })
  }, [socket])

  // console.log(weather.temp)
  

  return (
    <div>DetailedWeather
      <button onClick={sendmessage}>Send Message</button>
       {/* {weather.temp.map((curval)=><div>{curval}</div>)} */}
    </div>
  )
}
