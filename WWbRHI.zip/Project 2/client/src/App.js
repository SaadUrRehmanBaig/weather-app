import Login from "./component/login/Login";
import Register from "./component/register/Register";


function App() {
  return (
    <div className="App">
      {/* <Register/> */}
      <Login/>
    </div>
  );
}

export default App;
